package org.clever.Common.Exceptions;


public class SuspendException extends org.clever.Common.Exceptions.HyperVisorException {
    public SuspendException (String string){
        super(string);
    }
}