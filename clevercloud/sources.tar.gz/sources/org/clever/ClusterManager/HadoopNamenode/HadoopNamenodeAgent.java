/*
 * The MIT License
 *
 * Copyright 2013 Mariacristina Sinagra.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.clever.ClusterManager.HadoopNamenode;

/**
 *
 * @author cristina
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.clever.Common.Communicator.CmAgent;
import org.clever.Common.Communicator.Notification;
import org.clever.Common.Exceptions.CleverException;
import org.clever.Common.XMLTools.FileStreamer;
import org.clever.Common.XMLTools.ParserXML;
import java.io.OutputStream;
import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.clever.Common.Communicator.Agent;

public class HadoopNamenodeAgent extends CmAgent {

	private Logger logger;
	private Class cl;
	private HadoopNamenodePlugin NamenodePlugins;
	private String hostname;
	private String indirizzo;
	private String control;
	private String fsname;
	private String ip_address;
	private String agentId = "HadoopNamenodeAgent";
	private String slave;
	private String master;
	private String start;
	private String stop;
	private String coreHadoop;
	private String mapredHadoop;
	private String namespaceID;
	private String notifystart = "HADOOP";
	private String notifystop = "HADOOP/DOWN";
	private String space = "";
	private String ind[];
	private String user;
	private String s[];

	public HadoopNamenodeAgent() {
		super();
		logger = Logger.getLogger("HadoopNamenodeAgent");
	}

	@Override
	public void initialization() throws CleverException {
		List params;
		boolean exist;

		if (super.getAgentName().equals("NoName")) {
			super.setAgentName("HadoopNamenodeAgent");
		}


		super.start();


		try {
			logger.info("Read Configuration HadoopNamenodeAgent!");
			InputStream inxml = getClass().getResourceAsStream("/org/clever/ClusterManager/HadoopNamenode/configuration_HadoopNamenode.xml");
			FileStreamer fs = new FileStreamer();
			ParserXML pars = new ParserXML(fs.xmlToString(inxml));
			this.slave = pars.getElementContent("slaves");
			this.master = pars.getElementContent("masters");
			this.start = pars.getElementContent("startHadoop");
			this.stop = pars.getElementContent("stopHadoop");
			this.coreHadoop = pars.getElementContent("coreSite");
			this.mapredHadoop = pars.getElementContent("mapredSite");
			this.namespaceID = pars.getElementContent("spaceID");
			//register agent namenode to dispatcher agent
			List params2 = new ArrayList();
			params2.add(super.getAgentName());
			params2.add("HADOOP");
			this.invoke("DispatcherAgent", "subscribeNotification", true, params2);
			List params3 = new ArrayList();
			params3.add(super.getAgentName());
			params3.add("HADOOP/DOWN");
			this.invoke("DispatcherAgent", "subscribeNotification", true, params3);
			this.cl = Class.forName(pars.getElementContent("HadoopNamenodePlugin"));
			this.NamenodePlugins = (HadoopNamenodePlugin) this.cl.newInstance();
			this.NamenodePlugins.setModuleCommunicator(mc);
			this.NamenodePlugins.setOwner(this);
			//retrive username
			user = (String) System.getProperty("user.name");
			//retrieve hostname
			hostname = InetAddress.getLocalHost().getHostName();
			//retrieve ip address
			indirizzo = this.NamenodePlugins.networkIp();
			if (indirizzo.equals("ip error")) {

				logger.error("Error ip address");
			}

			// check if agent HadoopNamenodeAgent exists into db
			if (!(this.NamenodePlugins.checkHadoopAgent())) {
				// insert new agent and node
				this.NamenodePlugins.initHadoopAgent();
				this.NamenodePlugins.InsertItemIntoHadoopNode(hostname, indirizzo, user);
			} else {
				logger.info("The agent HadoopNamenodeAgent already exists !");
				//check if node (hostname) exists
				params = new ArrayList();
				params.add(agentId);
				params.add("/Hadoop/Node[@name='" + hostname + "']");
				if ((Boolean) (this.invoke("DatabaseManagerAgent", "existNode", true, params))) {
					logger.info("Node already exists !");
					params = new ArrayList();
					params.add(agentId);
					params.add("/Hadoop/Node[@name='" + hostname + "']");
					params.add("/ip/text()");
					String ip = (String) this.invoke("DatabaseManagerAgent", "getContentNodeXML", true, params);
					//check ip address 
					if (!(ip.equals(indirizzo))) {
						params = new ArrayList();
						params.add(agentId);
						params.add("text {'" + indirizzo + "'}");
						params.add("with");
						params.add("/Hadoop/Node[@name='" + hostname + "']/ip/text()");
						this.invoke("DatabaseManagerAgent", "updateNode", true, params);
					} else {
						logger.info("ip addresses match");
					}

				} else {
					//insert node 
					this.NamenodePlugins.InsertItemIntoHadoopNode(hostname, indirizzo, user);
					logger.info("Node added");
				}
			}
                        
                                                                                // GIOVANNI
                        if (!(this.NamenodePlugins.checkStorageNode())) {       // *
				// insert new agent and node                    // *
				this.NamenodePlugins.initStorageNode();         // *
                        }                                                       // *
                                                                                // *


			//retrieve namespaceID
			try {
				BufferedReader read = new BufferedReader(new FileReader(namespaceID));
				String line2;
				while (((line2 = read.readLine()) != null)) {
					if (line2.length() >= 11 && line2.substring(0, 11).equals("namespaceID")) {
						space = line2.substring(12);
						break;

					}
				}

				read.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

			/*following lines are commented because they are unnecessary up to now
			 params = new ArrayList();
			 params.add(agentId); //agentId
			 params.add("/Hadoop/Namespace[@name='" + hostname + "']"); 

			 if ((Boolean) (this.invoke("DatabaseManagerAgent", "existNode", true, params))) {
			 logger.info("namespaceID already exists !");
			 params = new ArrayList();
			 params.add(agentId);
			 params.add("/Hadoop/Namespace[@name='" + hostname + "']");
			 params.add("/id/text()");
			 String spaceID = (String) this.invoke("DatabaseManagerAgent", "getContentNodeXML", true, params);
			 if (!(spaceID.equals(space))) {
			 params = new ArrayList();
			 params.add(agentId);
			 params.add("text {'" + space + "'}");
			 params.add("with");
			 params.add("/Hadoop/Namespace[@name='" + hostname + "']/id/text()");
			 this.invoke("DatabaseManagerAgent", "updateNode", true, params);
			 } else {
			 logger.info("namespaces match");
			 }

			 } else {

			 this.NamenodePlugins.InsertItemIntoHadoopNamespace(hostname, space);
			 logger.info("Node added");
			 }
			 */



			//reading hosts alive from db 
			params = new ArrayList();
			params.add(agentId);
			params.add("/Hadoop/Node");
			List result = new ArrayList();
			result = (ArrayList) this.invoke("DatabaseManagerAgent", "getContentNode", true, params);
			int dim = result.size();
			ind = new String[dim];
			for (int i = 0, k = 0; i <= dim - 1; i = i + 3, k++) {
				ind[k] = (String) result.get(i) + " " + (String) result.get(i + 1);

			}
			try {
				Vector v = new Vector();
				BufferedReader in = new BufferedReader(new FileReader("/etc/hosts"));
				String line;
				while ((line = in.readLine()) != null) {
					v.add(line);
					logger.info("scrivo file" + line);
				}
				in.close();
				int n = v.size();
				for (int j = 0; ind[j] != null; j++) {
					exist = false;
					for (int k = 0; k < n; k++) {

						if ((ind[j].equals((v.elementAt(k))))) {
							exist = true;
							logger.info("element already exists ");

						}

					}

					if (!exist) {
						v.addElement(ind[j]);
						logger.info("added to vector");
					}

				}
				BufferedWriter b;
				b = new BufferedWriter(new FileWriter("/etc/hosts"));
				int t = v.size();
				for (int h = 0; h < t; h++) {
					b.write((String) v.elementAt(h) + "\n");
					logger.info("file written");

				}
				b.close();

			} catch (Exception e) {
				e.printStackTrace();
			}

			//configuration core-site, mapred-site, slaves
			Configuration conf = new Configuration(true);
			conf.addResource(new Path(coreHadoop));
			conf.addResource(new Path(mapredHadoop));
			conf.set("fs.default.name", "hdfs://" + hostname + ":54310");
			conf.set("mapred.job.tracker", hostname + ":8021");
			try {
				OutputStream out = new FileOutputStream(coreHadoop);
				conf.writeXml(out);
				logger.info("file corehadoop written");
				OutputStream out2 = new FileOutputStream(mapredHadoop);
				conf.writeXml(out2);
				logger.info("file mapred written");


			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			}




			//writing file slaves 
			s = new String[dim];
			logger.info("dim2" + dim);
			for (int i = 0, k = 0; i <= dim - 1; i = i + 3, k++) {
				//retrieve user@hostname
				s[k] = (String) result.get(i + 2) + "@" + (String) result.get(i + 1);

			}
			try {
				BufferedWriter c;
				c = new BufferedWriter(new FileWriter(slave));
				for (int j = 0; j < s.length && s[j] != null; j++) {
					if (!(s[j].equals(user + "@" + hostname))) {
						c.write(s[j] + "\n");
					}
				}
				c.close();

			} catch (Exception e) {
				e.printStackTrace();
			}


			//start hadoop daemons
			try {
				Runtime r = Runtime.getRuntime();
				Process p = r.exec(start);
				logger.info("Namenode started");
				try {
					p.waitFor();
				} catch (Exception e) {
					logger.error(e);
				}

			} catch (IOException e) {
				e.printStackTrace(System.err);
			}
                        //this.remoteInvocation(, "HadoopDatanodeAgent", "startDatanode", false, new ArrayList());
                        
                        logger.info("HadoopNamenode Plugin instantiated !");

		} catch (Exception e) {
			logger.error("Error initializing HadoopNamenode : " + e.getMessage());
		}
	}

	@Override
	public Class getPluginClass() {
		return cl;
	}

	@Override
	public Object getPlugin() {
		return NamenodePlugins;
	}

	@Override
	public void handleNotification(Notification notification) throws CleverException {
		logger.debug("Received notification type: " + notification.getId());

		if (notification.getId().equals(this.notifystart)) {
			String address = "";
			String usern;
			List params;
			try {
				try {
                                    //retrieve host ip address
                                    String host = notification.getHostId();
                                    params = new ArrayList();
                                    address = (String) ((CmAgent) this).remoteInvocation(host, "HadoopDatanodeAgent", "networkIp", true, params);
                                    //retrieve host user
                                    params = new ArrayList();
                                    usern = (String) ((CmAgent) this).remoteInvocation(host, "HadoopDatanodeAgent", "getUser", true, params);
                                    //check if host exists into db
                                    params = new ArrayList();
                                    params.add(agentId);
                                    params.add("/Hadoop/Node[@name='" + host + "']");
                                    if ((Boolean) (this.invoke("DatabaseManagerAgent", "existNode", true, params))) {
                                            logger.info("hostname already exists!");
                                            //check ip address
                                            params = new ArrayList();
                                            params.add(agentId);
                                            params.add("/Hadoop/Node[@name='" + host + "']");
                                            params.add("/ip/text()");
                                            String ip = (String) this.invoke("DatabaseManagerAgent", "getContentNodeXML", true, params);
                                            if (!(ip.equals(address))) {
                                                    params = new ArrayList();
                                                    params.add(agentId);
                                                    params.add("text {'" + address + "'}");
                                                    params.add("with");
                                                    params.add("/Hadoop/Node[@name='" + host + "']/ip/text()");
                                                    this.invoke("DatabaseManagerAgent", "updateNode", true, params);
                                            } else {
                                                    logger.info("ip addresses match");
                                            }

                                    } else {

                                            this.NamenodePlugins.InsertItemIntoHadoopNode(host, address, usern);
                                            logger.info("Node added");
                                    }

                                    //updating namenode file /etc/hosts 
                                    params = new ArrayList();
                                    params.add(address);
                                    params.add(host);
                                    this.invoke("HadoopNamenodeAgent", "setHosts", true, params);
                                    logger.info("New host added");

                                    //updating namenode file /conf/slaves
                                    params = new ArrayList();
                                    params.add(usern);
                                    params.add(host);
                                    this.invoke("HadoopNamenodeAgent", "setSlaves", true, params);
                                    logger.info("file slaves updated");

                                    //edit host /data/current/VERSION namespaceID
                                    List params2 = new ArrayList();
                                    params2.add(space);
                                    ((CmAgent) this).remoteInvocation(host, "HadoopDatanodeAgent", "modifySpace", true, params2);

                                    //edit host configuration

                                    List params3 = new ArrayList();
                                    params3.add(hostname);
                                    ((CmAgent) this).remoteInvocation(host, "HadoopDatanodeAgent", "setConf", true, params3);

                                    //retrieve host alive into cluster
                                    List params4 = new ArrayList();
                                    params4 = new ArrayList();
                                    params4.add(agentId);
                                    params4.add("/Hadoop/Node");
                                    params4.add("/host/text()");
                                    String id = (String) this.invoke("DatabaseManagerAgent", "getHostName", true, params4);
                                    String[] arr = id.split("\\n");

                                    List params5 = new ArrayList();
                                    params5 = new ArrayList();
                                    params5.add(agentId);
                                    params5.add("/Hadoop/Node");
                                    List result = new ArrayList();
                                    result = (ArrayList) this.invoke("DatabaseManagerAgent", "getContentNode", true, params5);
                                    int dim = result.size();
                                    String inf[] = new String[dim];
                                    for (int i = 0, k = 0; i <= dim - 1; i = i + 2, k++) {
                                            inf[k] = (String) result.get(i) + " " + (String) result.get(i + 1);

                                    }
                                    for (int i = 0; i < arr.length; i++) {
                                            if (!(arr[i].equals(hostname))) {
                                                    //edit all /etc/hosts file 
                                                    String tmp = arr[i];
                                                    params = new ArrayList();
                                                    params.add(inf);
                                                    ((CmAgent) this).remoteInvocation(tmp, "HadoopDatanodeAgent", "modifyHosts", true, params);

                                            }
                                    }
                                } catch (Exception ex) {
                                    this.logger.error("Error configuring datanode resources: " + ex.getMessage());
                                }
                                this.remoteInvocation(notification.getHostId(), "HadoopDatanodeAgent", "startDatanode", false, new ArrayList());
			} catch (Exception ex) {
				throw new CleverException("Configuration hosts failed");
			}
		}

		if (notification.getId().equals(this.notifystop)) {
			String address = "";

			List params;
			try {
				String host = notification.getHostId();
				params = new ArrayList();
				address = (String) ((CmAgent) this).remoteInvocation(host, "HadoopDatanodeAgent", "networkIp", true, params);
				params = new ArrayList();
				params.add(agentId);
				params.add("/Hadoop/Node[@name='" + host + "']");

				if ((Boolean) (this.invoke("DatabaseManagerAgent", "existNode", true, params))) {
					logger.info("hostname already exists!");
					params = new ArrayList();
					params.add(agentId);
					params.add("/Hadoop/Node[@name='" + host + "']");
					params.add("/ip/text()");
					String ip = (String) this.invoke("DatabaseManagerAgent", "getContentNodeXML", true, params);
					if ((ip.equals(address))) {
						params = new ArrayList();
						params.add(agentId);
						params.add("/Hadoop/Node[@name='" + hostname + "']");
						this.invoke("DatabaseManagerAgent", "deleteNode", true, params);
						logger.info("Node deleted");
						//update namenode file /etc/hosts
						this.NamenodePlugins.updateHosts(address, host);

						//update namenode file /conf/slaves
						params = new ArrayList();
						params.add(agentId);
						params.add("/Hadoop/Node");
						List result = new ArrayList();
						result = (ArrayList) this.invoke("DatabaseManagerAgent", "getContentNode", true, params);
						int dim = result.size();
						String node[] = new String[dim];
						for (int i = 0, k = 0; i <= dim - 1; i = i + 3, k++) {
							//retrieve (ip_address hostname)
							node[k] = (String) result.get(i + 2) + " " + (String) result.get(i + 1);
							try {
								BufferedWriter c;
								c = new BufferedWriter(new FileWriter(slave));
								for (int j = 0; j < node.length && node[j] != null; j++) {
									if (!(node[j].equals(user + "@" + hostname))) {
										c.write(node[j] + "\n");
									}
								}

								c.close();

							} catch (Exception e) {
								e.printStackTrace();
							}
						}

						//update all /etc/hosts files
						params = new ArrayList();
						params = new ArrayList();
						params.add(agentId);
						params.add("/Hadoop/Node");
						params.add("/host/text()");
						String mod = (String) this.invoke("DatabaseManagerAgent", "getHostName", true, params);
						String[] array = mod.split("\\n");
						for (int i = 0; i < array.length; i++) {
							if (!(array[i].equals(hostname))) {
								String tmp = array[i];
								params = new ArrayList();
								params.add("address");
								params.add("host");
								((CmAgent) this).remoteInvocation(tmp, "HadoopDatanodeAgent", "updateHosts", true, params);
							}
						}
					}
				}
			} catch (Exception ex) {
				throw new CleverException("Configuration hosts failed");
			}
		}
	}

	@Override
	public void shutDown() {

		Process p;

		try {
			Runtime r = Runtime.getRuntime();
			p = r.exec(stop);
			logger.info("Hdfs stopped");
		} catch (IOException e) {
			e.printStackTrace(System.err);
		}

		try {
			//delete namenode from db
			List params;
			params = new ArrayList();
			params.add(agentId);
			params.add("/Hadoop/Node[@name='" + hostname + "']");
			this.invoke("DatabaseManagerAgent", "deleteNode", true, params);
			logger.info("Node deleted");
			/*  following lines are commented because they are unnecessary up to now
			 params=new ArrayList();
			 params.add(agentId);
			 params.add("/Hadoop/Namespace");
			 this.invoke("DatabaseManagerAgent", "deleteNode", true, params);
			 logger.info("Nodo namespace cancellato");
			 */

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
