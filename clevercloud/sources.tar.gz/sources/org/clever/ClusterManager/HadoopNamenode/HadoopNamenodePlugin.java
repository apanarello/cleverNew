/*
 * The MIT License
 *
 * Copyright 2013 mariacristina sinagra.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.clever.ClusterManager.HadoopNamenode;



import java.io.IOException;
import java.util.List;
import org.apache.hadoop.fs.Path;
import org.clever.Common.Communicator.Agent;
import org.clever.Common.Communicator.ModuleCommunicator;
import org.clever.Common.Exceptions.CleverException;
import org.clever.Common.Plugins.RunnerPlugin;
import org.clever.Common.Storage.VFSDescription;


/**
 *
 * @author cristina
 */
public interface HadoopNamenodePlugin {
    
    public void setModuleCommunicator(ModuleCommunicator mc);
     
    public ModuleCommunicator getModuleCommunicator();
     
    public String networkIp();
     
    public boolean existsHost(String address, String name) throws Exception;
     
    public void setHosts(String address, String name) throws Exception;
    
    public void updateHosts(String address, String name) throws Exception;
    
    public void setSlaves(String username, String name) throws Exception;
     
    public boolean checkHadoopAgent() throws CleverException;
     
    public void initHadoopAgent() throws CleverException;
    
    public boolean checkStorageNode() throws CleverException; //GIOVANNI
     
    public void initStorageNode() throws CleverException; //GIOVANNI
    
    public void InsertItemIntoHadoopNode(String hostname, String address, String username) throws CleverException;
    
    /*following lines are commented because they are unnecessary up to now
	public void InsertItemIntoHadoopNamespace(String hostname, String namespace) throws CleverException;
    */  
    //Hadoop methods
      
    public String copyFromLocal (String source, String dest) throws IOException;
      
    public String copyFromHdfs (String source, String dest) throws IOException;
    
    public String moveFromLocal (String source, String dest) throws IOException;

    public String moveToLocal (String source, String dest) throws IOException;
    
    public String renameFile (String fromthis, String tothis) throws IOException;
      
    public String addFile(String source, String dest) throws IOException;
      
    public String deleteFile(String file) throws Exception; 
     
   // public String mkdir(String dir) throws IOException;
      
    public boolean ifExists (String domain, String source) throws CleverException;
    // public String ifExists (String source) throws IOException;
    
    public String submitJob(String input, String output) throws Exception;
     
    public void setOwner(Agent owner);
    
}
