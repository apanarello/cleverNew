/*
 * The MIT License
 *
 * Copyright 2013 mariacristina sinagra.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.clever.ClusterManager.HadoopPlugin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import org.apache.log4j.Logger;
import org.clever.ClusterManager.HadoopNamenode.HadoopNamenodePlugin;
import org.clever.Common.Communicator.Agent;
import org.clever.Common.Communicator.ModuleCommunicator;
import org.clever.Common.Exceptions.CleverException;
import org.clever.Common.XMLTools.ParserXML;
import org.jdom.Element;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DistributedFileSystem;
import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.clever.Common.XMLTools.FileStreamer;
/**
 *
 * @author cristina
 */
public class NamenodePlugin implements HadoopNamenodePlugin{
     
    private Logger logger;
    private Class cl;
    private ModuleCommunicator mc;
    private String hostName;
    private ParserXML pXML;
    private Agent owner;
    private String nodoHadoop="Hadoop";
    private String coreHadoop;
    private String hdfsHadoop;
    private String mapredHadoop;
    private String slave;
    
    public final static String storageNode = "HadoopStorage";
    public final static String domainNode = "domain";
    public final static String agentName = "HadoopNamenodeAgent";
    public final static String nameAttribute = "name";
    public final static String fileNode = "file";
    public final static String containerDomainNode = "containerDomain";
    public final static String UIDNode = "UID";
    public final static String localDomain = "LOCAL";
    
    /**
    * Instantiates a new NamenodePlugin object
    */
    public NamenodePlugin() {
        this.logger = Logger.getLogger("NamenodePlugin");
        try{
            logger.info("Read Configuration HadoopNamenodeAgent!");
            InputStream inxml = getClass().getResourceAsStream("/org/clever/ClusterManager/HadoopNamenode/configuration_HadoopNamenode.xml");
            FileStreamer fs = new FileStreamer();
            ParserXML pars = new ParserXML(fs.xmlToString(inxml));
            this.coreHadoop=pars.getElementContent("coreSite");
            this.hdfsHadoop=pars.getElementContent("hdfsSite");
            this.mapredHadoop=pars.getElementContent("mapredSite");
            this.slave = pars.getElementContent("slaves");
				//retrieve hostname		
                try{hostName = InetAddress.getLocalHost().getHostName();
                    } 
             catch (UnknownHostException e) {
            this.logger.error("Error getting local host name :" + e.getMessage());
        }
        }   catch (IOException e) {
                e.printStackTrace(System.err);
                this.logger.error("Error reading configuration");
            }
    }
    

    @Override
    public void setModuleCommunicator(ModuleCommunicator m) {
        this.mc = m;
    }

    @Override
    public ModuleCommunicator getModuleCommunicator() {
      return this.mc;
    }
	
	
	//retrieve ip address
    @Override
    public String networkIp() 
    {
        Enumeration<NetworkInterface> ifaces = null;
        try {
            ifaces = NetworkInterface.getNetworkInterfaces();
        }
        catch (SocketException e) {
            e.printStackTrace();
        }
        
        for ( ; ifaces.hasMoreElements(); ){
            NetworkInterface iface = ifaces.nextElement();
            //System.out.println(iface.getName() + ":");

            for (Enumeration<InetAddress> addresses =iface.getInetAddresses();addresses.hasMoreElements(); ){
                InetAddress address = addresses.nextElement();
                String str=address.toString().substring(1);
                if(address.isSiteLocalAddress() && !address.isLoopbackAddress() && !(address.getHostAddress().indexOf(":")>-1))
                    return str;
            }
        }

        try {
            return InetAddress.getLocalHost().getHostAddress();
        }
        catch (UnknownHostException ex) {
            return "ip error";
        }
    }
    

	//edit /etc/hosts file
    	/**
	 *
	 * @param address ip_address of the host
	 * @param name hostname of the host
	 * @throws Exception
	 */
	@Override
    public void setHosts(String address, String name) throws Exception{
   
        BufferedReader in=new BufferedReader(new FileReader("/etc/hosts"));
        String line;
        StringBuffer buffer=new StringBuffer();
        while((line=in.readLine())!= null){
            buffer.append(line + "\n");
        }
        in.close();
        BufferedWriter b;
        b=new BufferedWriter (new FileWriter ("/etc/hosts"));

        b.write(buffer.toString());
		//insert (ip_address hostname) at the end of file
        b.write(address + "\t" + name);

        b.close();
   }
    
    //edit /conf/slaves file
    	/**
	 *
	 * @param username  username of the host added
	 * @param name hostname of the host added
	 * @throws Exception
	 */
	@Override
     public void setSlaves(String username, String name) throws Exception{
   
        BufferedReader in=new BufferedReader(new FileReader(slave));
        String line;
        StringBuffer buffer=new StringBuffer();
        while((line=in.readLine())!= null){
            buffer.append(line + "\n");
        }
        in.close();
        BufferedWriter b;
        b=new BufferedWriter (new FileWriter (slave));

        b.write(buffer.toString());

        b.write(username+"@"+name);

        b.close();
   }
    
	//check if exists hostname in the /etc/hosts file
    	/**
	 *
	 * @param address  ip_address of the host
	 * @param name hostname of the host
	 * @return
	 * @throws Exception
	 */
        
	@Override
    public boolean existsHost(String address, String name) throws Exception{
        boolean exists=false;
     
        BufferedReader in=new BufferedReader(new FileReader("/etc/hosts"));
        String line;
        StringBuffer buffer=new StringBuffer();

        while(((line=in.readLine())!= null) && !exists ){   
            System.out.println(line);
            if(line.equals(address + " " + name))              
                exists=true;
        }

        in.close();

        return exists;
    }
    
	
    	/**
	 *
	 * @param address ip_address of the host
	 * @param name hostname of the host
	 * @throws Exception
	 */
	@Override
    public void updateHosts(String address, String name) throws Exception{
         BufferedReader in = new BufferedReader(new FileReader("/etc/hosts"));
        String line;
        StringBuffer buffer = new StringBuffer();
        while ((line = in.readLine()) != null) {
            if(!(line.equals(address + " " + name)))
            buffer.append(line + "\n");
        }
        in.close();
        BufferedWriter b;
        b = new BufferedWriter(new FileWriter("/etc/hosts"));

        b.write(buffer.toString());

      
        b.close();
    }

   
    @Override
    public boolean checkHadoopAgent() throws CleverException{
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add("/"+this.nodoHadoop); 
        return (Boolean)this.owner.invoke("DatabaseManagerAgent", "checkAgentNode", true, params);
    }
    
    @Override
    public void initHadoopAgent() throws CleverException{
        String node="<"+this.nodoHadoop+"/>";
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add(node);
        params.add("into");
        params.add(""); 
        this.owner.invoke("DatabaseManagerAgent", "insertNode", true, params);
     }
    
    @Override
    public boolean checkStorageNode() throws CleverException{
        List params = new ArrayList();
        params.add(NamenodePlugin.agentName);
        params.add("/"+NamenodePlugin.storageNode); 
        return (Boolean)this.owner.invoke("DatabaseManagerAgent", "checkAgentNode", true, params);
    }

    @Override
    public void initStorageNode() throws CleverException{
        String node="<"+NamenodePlugin.storageNode+"/>";
        List params = new ArrayList();
        params.add(NamenodePlugin.agentName);
        params.add(node);
        params.add("into");
        params.add(""); 
        this.owner.invoke("DatabaseManagerAgent", "insertNode", true, params);
     }
     
    	/**
	 *
	 * @param hostname hostname of the hadoop host
	 * @param address ip_address of the hadoop host
	 * @param username username of the hadoop host
	 * @throws CleverException
	 */
	@Override    
    public void InsertItemIntoHadoopNode(String hostname, String address, String username) throws CleverException {
        String node="<Node name=\""+hostname+"\" request=\""+new Date().toString()+"\""+">"
                         +"<ip>"+address+"</ip>"
                         +"<host>"+hostname+"</host>"
                         +"<user>"+username+"</user>"
                    +"</Node>";
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add(node);
        params.add("into");
        params.add("/"+this.nodoHadoop);
        this.owner.invoke("DatabaseManagerAgent", "insertNode", true, params);
    }
    
	/*
     @Override    
    public void InsertItemIntoHadoopNamespace(String hostname, String namespace) throws CleverException {
        String node="<Namespace name=\""+hostname+"\" request=\""+new Date().toString()+"\""+">"
                         +"<id>"+namespace+"</id>"
                   +"</Namespace>";
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add(node);
        params.add("into");
        params.add("/"+this.nodoHadoop);
        this.owner.invoke("DatabaseManagerAgent", "insertNode", true, params);
    }
    */

    @Override
        public void setOwner(Agent owner){
        this.owner=owner;
    }

    @Override
    public String copyFromLocal(String source, String dest) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String copyFromHdfs(String source, String dest) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String moveFromLocal(String source, String dest) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String moveToLocal(String source, String dest) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String renameFile(String fromthis, String tothis) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String addFile(String source, String dest) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String deleteFile(String file) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /** INUTILE perchè USO GLI UID per salvare i file
    @Override
    public String mkdir(String dir) throws IOException {
        Configuration conf = new Configuration();
        conf.addResource(new Path(coreHadoop));
        conf.addResource(new Path(hdfsHadoop));
        conf.addResource(new Path(mapredHadoop));

        FileSystem fileSystem = FileSystem.get(conf);

        Path path = new Path(dir);
        if (fileSystem.exists(path)) {
           logger.info("Dir " + dir + " already exists!");
            return "The directory already exists";
        }

        fileSystem.mkdirs(path);

        fileSystem.close();
        
        return "Directory created";
    } */

    
    
    @Override
    public boolean ifExists (String domain, String source) throws CleverException {
        return this.existsFileNode(domain, source);
    }

    
    
    @Override
    
    public String submitJob(String input, String output) throws Exception{
        Configuration conf=new Configuration();
        conf.addResource(new Path(coreHadoop));
        conf.addResource(new Path(mapredHadoop));
         conf.addResource(new Path(hdfsHadoop));
        
        
        Job job = new Job(conf);
                job.setJarByClass(WordCount.class);
                job.setJobName("wordcount");
                
                job.setOutputKeyClass(Text.class);
                job.setOutputValueClass(IntWritable.class);
                
                job.setMapperClass(WordCount.WordCountMap.class);
                job.setCombinerClass(WordCount.WordCountReducer.class);
                job.setReducerClass(WordCount.WordCountReducer.class);
                
                
                job.setInputFormatClass(TextInputFormat.class);
                job.setOutputFormatClass(TextOutputFormat.class);
                
                
                FileInputFormat.setInputPaths(job, new Path(input));
                FileOutputFormat.setOutputPath(job, new Path(output));
                
                boolean success=job.waitForCompletion(true);
                if (success)
                    return "Job ok";
                else
                    return "Job failed";
                    
                
               // System.exit(job.waitForCompletion(true) ? 0 : 1);
               
    }
    
    
    
    private boolean existsDomainNode (String domain) throws CleverException {
        ArrayList<Object> params = new ArrayList<Object>();
        String location = "/"+NamenodePlugin.storageNode;
        location += "/"+NamenodePlugin.domainNode+"[@"+NamenodePlugin.nameAttribute+"='"+domain+"']";
        params.add(NamenodePlugin.agentName);
        params.add(location);
        return (Boolean)this.owner.invoke("DatabaseManagerAgent", "existNode", true, params);
    }
    
    
    
    private boolean existsFileNode (String domain, String file) throws CleverException {
        if (!this.existsDomainNode(domain))
            return false;
        ArrayList<Object> params = new ArrayList<Object>();
        String location = "/"+NamenodePlugin.storageNode;
        location += "/"+NamenodePlugin.domainNode+"[@"+NamenodePlugin.nameAttribute+"='"+domain+"']";
        location += "/"+ NamenodePlugin.fileNode +"[@"+NamenodePlugin.nameAttribute+"='"+ file +"']";
        params.add(NamenodePlugin.agentName);
        params.add(location);
        return (Boolean)this.owner.invoke("DatabaseManagerAgent", "existNode", true, params);
    }
    
    private void addDomainNode (String domain) throws CleverException {
        if (this.existsDomainNode(domain))
            return;
        ArrayList<Object> params = new ArrayList<Object>();
        String node = "<"+NamenodePlugin.domainNode+"/>";
        String location = "/"+NamenodePlugin.storageNode;
        params.add(NamenodePlugin.agentName);
        params.add(node);
        params.add("into");
        params.add(location);
        this.owner.invoke("DatabaseManagerAgent", "insertNode", false, params);
    }
    
    private void addFileNode (String domain, String file, String domainContainer, String UID) throws CleverException {
        if (this.existsFileNode(domain, file))
            throw new CleverException ("A file with the specified name is already present. Use another name.");
        if (!this.existsDomainNode(domain))
            this.addDomainNode(domain);
        ArrayList<Object> params = new ArrayList<Object>();
        String node = "<"+NamenodePlugin.fileNode+" name=\""+file+"\">"
                + "<"+NamenodePlugin.containerDomainNode+">"+domainContainer+"</"+NamenodePlugin.containerDomainNode+">"
                + "<"+NamenodePlugin.UIDNode+">"+UID+"</"+NamenodePlugin.UIDNode+">"
                + "</"+NamenodePlugin.fileNode+">";
        String location = "/"+NamenodePlugin.storageNode
                + "/"+NamenodePlugin.domainNode
                +"[@"+NamenodePlugin.nameAttribute+"='"+domain+"']";
        params.add(NamenodePlugin.agentName);
        params.add(node);
        params.add("into");
        params.add(location);
        this.owner.invoke("DatabaseManagerAgent", "insertNode", false, params);
    }
    
    private void updateFileNode (String domain, String file, String domainContainer, String UID) throws CleverException {
        if (this.existsFileNode(domain, file))
            this.removeFileNode(domain, file);
        this.addFileNode(domain, file, domainContainer, UID);
    }
    
    private void removeFileNode (String domain, String file) throws CleverException {
        if (!this.existsDomainNode(domain))
            throw new CleverException ("Client domain doesn't exist");
        if (!this.existsFileNode(domain, file))
            throw new CleverException ("File doesn't exist");
        ArrayList<Object> params = new ArrayList<Object>();
        String location = "/"+NamenodePlugin.storageNode
            + "/"+NamenodePlugin.domainNode+"[@"+NamenodePlugin.nameAttribute+"='"+domain+"']"
            + "/"+ NamenodePlugin.fileNode +"[@"+NamenodePlugin.nameAttribute+"='"+ file +"']";
        params.add(NamenodePlugin.agentName);
        params.add(location);
        this.owner.invoke("DatabaseManagerAgent", "deleteNode", false, params);
    }
    
    private void removeDomainNode (String domain) throws CleverException {
        if (!this.existsDomainNode(domain))
            throw new CleverException ("Client domain doesn't exist");
        ArrayList<Object> params = new ArrayList<Object>();
        String location = "/"+NamenodePlugin.storageNode
            + "/"+NamenodePlugin.domainNode+"[@"+NamenodePlugin.nameAttribute+"='"+domain+"']";
        params.add(NamenodePlugin.agentName);
        params.add(location);
        String content = (String)this.owner.invoke("DatabaseManagerAgent", "getContentNodeObject", true, params);
        if (!content.isEmpty())
            throw new CleverException ("There are files appartaining to the domain. First delete them.");
        params.clear();
        location = "/"+NamenodePlugin.storageNode
            + "/"+NamenodePlugin.domainNode+"[@"+NamenodePlugin.nameAttribute+"='"+domain+"']";
        params.add(NamenodePlugin.agentName);
        params.add(location);
        this.owner.invoke("DatabaseManagerAgent", "deleteNode", false, params);
    }
    
    

}
