/*
 * The MIT License
 *
 * Copyright 2013 mariacristina sinagra.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.clever.HostManager.DatanodePlugin;

/**
 *
 * @author cristina
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import org.apache.log4j.Logger;
import org.clever.ClusterManager.HadoopNamenode.HadoopNamenodePlugin;
import org.clever.ClusterManager.StorageManager.StorageManagerPlugin;
import org.clever.Common.Communicator.Agent;
import org.clever.Common.Communicator.ModuleCommunicator;
import org.clever.Common.Exceptions.CleverException;
import org.clever.Common.XMLTools.ParserXML;
import org.jdom.Element;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.clever.Common.XMLTools.FileStreamer;
import org.clever.HostManager.HadoopDatanode.HadoopDatanodePlugin;

public class PluginDatanode implements HadoopDatanodePlugin {

    private Logger logger;
    private Class cl;
    private ModuleCommunicator mc;
    private String hostName;
    private ParserXML pXML;
    private Agent owner;
    private String nodoHadoop = "Hadoop";
    private String coreHadoop;
    private String hdfsHadoop;
    private String mapredHadoop;
    private String namespaceID;
    private String start;
    private String stop;
    
    public PluginDatanode()  {
        this.logger = Logger.getLogger("PluginDatanode");
        try {
            logger.info("Read Configuration HadoopDatanodeAgent!");
            InputStream inxml = getClass().getResourceAsStream("/org/clever/HostManager/HadoopDatanode/configuration_datanode.xml");
            FileStreamer fs = new FileStreamer();
            ParserXML pars = new ParserXML(fs.xmlToString(inxml));
            this.coreHadoop = pars.getElementContent("coreSite");
            this.hdfsHadoop = pars.getElementContent("hdfsSite");
            this.mapredHadoop = pars.getElementContent("mapredSite");
            this.namespaceID = pars.getElementContent("spaceID");
            logger.info(coreHadoop);

            try {
                hostName = InetAddress.getLocalHost().getHostName();
            } catch (UnknownHostException e) {
                this.logger.error("Error getting local hostname :" + e.getMessage());
            }
        } catch (IOException e) {
            e.printStackTrace(System.err);
            this.logger.error("Error reading configuration");
        }
    }

    @Override
    public void setModuleCommunicator(ModuleCommunicator m) {
        this.mc = m;
    }

    @Override
    public ModuleCommunicator getModuleCommunicator() {
        return this.mc;
    }
    
    //get username
    @Override
    public String getUser() throws Exception{
        
        String username=(String) System.getProperty("user.name");
        return username;
    }
    
    
    //get ip_address
    @Override
    public String networkIp() {
        Enumeration<NetworkInterface> ifaces = null;
        try {
            ifaces = NetworkInterface.getNetworkInterfaces();
        } catch (SocketException e) {
            e.printStackTrace();
        }

        for (; ifaces.hasMoreElements();) {
            NetworkInterface iface = ifaces.nextElement();
           

            for (Enumeration<InetAddress> addresses = iface.getInetAddresses(); addresses.hasMoreElements();) {
                InetAddress address = addresses.nextElement();
                String str = address.toString().substring(1);
                if (address.isSiteLocalAddress() && !address.isLoopbackAddress() && !(address.getHostAddress().indexOf(":") > -1)) {
                    return str;
                }
            }
        }

        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException ex) {
            return "ip error";
        }
    }

    	/**
	 *
	 * @param address ip_address of the host
	 * @param name hostname of the host
	 * @throws Exception
	 */
	@Override
    public void setHosts(String address, String name) throws Exception {

        BufferedReader in = new BufferedReader(new FileReader("/etc/hosts"));
        String line;
        StringBuffer buffer = new StringBuffer();
        while ((line = in.readLine()) != null) {
            buffer.append(line + "\n");
        }
        in.close();
        BufferedWriter b;
        b = new BufferedWriter(new FileWriter("/etc/hosts"));

        b.write(buffer.toString());

        b.write(address + " " + name);

        b.close();
    }

    	/**
	 *
	 * @param address ip_address of the host
	 * @param name hostname of the host
	 * @return
	 * @throws Exception
	 */
	@Override
    public boolean existsHost(String address, String name) throws Exception {
        boolean exists = false;

        BufferedReader in = new BufferedReader(new FileReader("/etc/hosts"));
        String line;
        StringBuffer buffer = new StringBuffer();

        while (((line = in.readLine()) != null) && !exists) {
            System.out.println(line);
            if (line.equals(address + " " + name)) {
                exists = true;
            }
        }

        in.close();

        return exists;
    }

    
    	/**
	 *
	 * @param address ip_address of the host
	 * @param name hostname of the host
	 * @throws Exception
	 */
	@Override 
    public void updateHosts(String address, String name) throws Exception{
         BufferedReader in = new BufferedReader(new FileReader("/etc/hosts"));
        String line;
        StringBuffer buffer = new StringBuffer();
        while ((line = in.readLine()) != null) {
            if(!(line.equals(address + " " + name)))
            buffer.append(line + "\n");
        }
        in.close();
        BufferedWriter b;
        b = new BufferedWriter(new FileWriter("/etc/hosts"));

        b.write(buffer.toString());

      
        b.close();
}
    
    /*
    @Override
    public boolean checkHadoopAgent() throws CleverException {
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add("/" + this.nodoHadoop); //XPath location with eventual predicate
        return (Boolean)this.owner.invoke("DatabaseManagerAgent", "checkAgentNode", true, params);
    }

    @Override
    public void initHadoopAgent() throws CleverException {
        String node = "<" + this.nodoHadoop + "/>";
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add(node);
        params.add("into");
        params.add(""); //XPath location with eventual predicate
        this.owner.invoke("DatabaseManagerAgent", "insertNode", true, params);
    }

    @Override
    public void InsertItemIntoHadoopNode(String hostname, String address) throws CleverException {
        String node = "<Node name=\"" + hostname + "\" request=\"" + new Date().toString() + "\"" + ">"
                + "<ip>" + address + "</ip>"
                + "<host>" + hostname + "</host>"
                + "</Node>";
        List params = new ArrayList();
        params.add("HadoopNamenodeAgent");
        params.add(node);
        params.add("into");
        params.add("/" + this.nodoHadoop);
        this.owner.invoke("DatabaseManagerAgent", "insertNode", true, params);
    }
*/

  	/**
	 *
	 * @param name path to set the namespace
	 * @throws Exception
	 */
	@Override
   public void modifySpace(String name) throws Exception{
       try {
                    BufferedReader read = new BufferedReader(new FileReader(namespaceID));
                    String line2;
                    StringBuffer buffer = new StringBuffer();


                    while (((line2 = read.readLine()) != null)) {
                        if (line2.length() >= 11 && line2.substring(0, 11).equals("namespaceID")) {
                            buffer.append("namespaceID=" + name + "\n");
                        }
                        buffer.append(line2 + "\n");


                    }

                    read.close();
                    BufferedWriter b;
                    b = new BufferedWriter(new FileWriter(namespaceID));
                    b.write(buffer.toString());
                    b.close();


                } catch (Exception e) {
                    e.printStackTrace();
                }
      
      
  }

    	/**
	 *
	 * @param array list of the hosts alive in the cluster
	 * @throws Exception
	 */
	public void modifyHosts(String[] array) throws Exception{
    
        Vector v=new Vector();
        boolean exists;
     
        try {
                    //memorizzo il file nel vettore v e controllo che non siano presenti elementi uguali, in caso contrario li aggiungo al vettore
                    BufferedReader in = new BufferedReader(new FileReader("/etc/hosts"));
                    String line;
                    while ((line = in.readLine()) != null) 
                    {
                        v.add(line);
                        logger.info("writing file" + line);             
                    }
                    in.close();
                    int n = v.size();
                    for (int j = 0; array[j] != null; j++) {
                        exists = false;                  
                        for (int k = 0; k < n; k++) {

                            if ((array[j].equals((v.elementAt(k))))) {
                                exists = true;
                                logger.info("element already exists");

                            }

                        }

                        if (!exists) {
                            v.addElement(array[j]);
                            logger.info("element added to vector");
                        }

                    }
                    BufferedWriter b;
                    b = new BufferedWriter(new FileWriter("/etc/hosts"));
                    int t = v.size();
                    for (int h = 0; h < t; h++) {
                        b.write((String) v.elementAt(h) + "\n");
                        logger.info("file written");

                    }
                    b.close();

                } catch (Exception e) {
                    e.printStackTrace();
                }
    
    
    
    
    }
    
    	/**
	 *
	 * @param hostname hostname of the namenode
	 * @throws Exception
	 */
	@Override
    public void setConf(String hostname) throws Exception{
        
         Configuration conf = new Configuration();
                conf.addResource(new Path(coreHadoop));
                conf.addResource(new Path(mapredHadoop));
                conf.set("fs.default.name", "hdfs://" + hostname + ":54310");
                conf.set("mapred.job.tracker", hostname + ":8021");
                try {
                    OutputStream out = new FileOutputStream(coreHadoop);
                    conf.writeXml(out);
                    OutputStream out2 = new FileOutputStream(mapredHadoop);
                    conf.writeXml(out2);

                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
        
    }
    
   
    
    @Override
    public void setOwner(Agent owner) {
        this.owner = owner;
    }

    @Override
    public void startDatanode() throws IOException {
        Configuration c = new Configuration(true);
        c.addResource(this.coreHadoop);
        c.addResource(this.hdfsHadoop);
        String dataDir = c.get("dfs.data.dir");
        if (dataDir.startsWith("${hadoop.tmp.dir}"))
            dataDir = c.get("hadoop.tmp.dir") + dataDir.substring(17, dataDir.length());
        File dir = new File (dataDir);
	this.logger.info("Deleting old data dir");
        if (dir.exists())
            FileUtils.deleteDirectory(dir);
        Runtime r = Runtime.getRuntime();
	Process p = r.exec(this.start);
	this.logger.info("Datanode started");
    }

    @Override
    public void setStartCommand(String command) {
        this.start = command;
    }

    @Override
    public void setStopCommand(String command) {
        this.stop = command;
    }
}
