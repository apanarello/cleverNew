/*
 * The MIT License
 *
 * Copyright 2013 mariacristina sinagra.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.clever.HostManager.HadoopDatanode;

/**
 *
 * @author cristina
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.clever.Common.Communicator.CmAgent;
import org.clever.Common.Communicator.Notification;
import org.clever.Common.Exceptions.CleverException;
import org.clever.Common.XMLTools.FileStreamer;
import org.clever.Common.XMLTools.ParserXML;
import java.io.OutputStream;
import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import org.clever.Common.Communicator.Agent;
//import org.jdom2.*;

public class HadoopDatanodeAgent extends Agent {

    private Logger logger;
    private Class cl;
    private HadoopDatanodePlugin DatanodePlugins;
    private String hostname;
    private String indirizzo;
    private String control;
    private String fsname;
    private String ip_address;
    private String agentId = "HadoopNamenodeAgent";
    private String slave;
    private String master;
    private String start;
    private String stop;
    private String coreHadoop;
    private String mapredHadoop;
    private String namespaceID;
    private String id;

    public HadoopDatanodeAgent()  {
        super();
        logger = Logger.getLogger("HadoopDatanodeAgent");
    }

    @Override
    public void initialization() {
        List params;
        Vector v = new Vector();
        boolean exist;
        String space = "";
        String host = "";

        if (super.getAgentName().equals("NoName")) {
            super.setAgentName("HadoopDatanodeAgent");
        }

        try {
            super.start();

            logger.info("Read Configuration HadoopDatanodeAgent!");
            InputStream inxml = getClass().getResourceAsStream("/org/clever/HostManager/HadoopDatanode/configuration_datanode.xml");
            FileStreamer fs = new FileStreamer();
            ParserXML pars = new ParserXML(fs.xmlToString(inxml));
			this.cl = Class.forName(pars.getElementContent("HadoopDatanodePlugin"));
            this.DatanodePlugins = (HadoopDatanodePlugin) this.cl.newInstance();
            this.DatanodePlugins.setModuleCommunicator(mc);
            this.DatanodePlugins.setOwner(this);
            this.DatanodePlugins.setStartCommand(pars.getElementContent("startCommand"));
            this.DatanodePlugins.setStopCommand("stopCommand");
            this.coreHadoop = pars.getElementContent("coreSite");
            this.mapredHadoop = pars.getElementContent("mapredSite");

            hostname = InetAddress.getLocalHost().getHostName();
            indirizzo = this.DatanodePlugins.networkIp();
            if (indirizzo.equals("ip error")) {
               logger.error("Error initializing file /etc/hosts:" + hostname);
            }
			// send notification to dispatcher agent
			Notification not=new Notification();
			not.setHostId(hostname);
			not.setId("HADOOP");
			this.sendNotification(not);
			logger.info("notification HADOOP sent");              

            logger.info("HadoopDatanodePlugin created ");
        } catch (CleverException ex) {
            java.util.logging.Logger.getLogger(HadoopDatanodeAgent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            logger.error("Error: " + ex);
        } catch (IOException ex) {
            logger.error("Error: " + ex);
        } catch (InstantiationException ex) {
            logger.error("Error: " + ex);
        } catch (IllegalAccessException ex) {
            logger.error("Error: " + ex);
        } catch (Exception ex) {
            logger.error("HadoopDatanodePlugin creation failed: " + ex);
        }



    }

    @Override
    public Class getPluginClass() {
        return cl;
    }

    @Override
    public Object getPlugin() {
        return DatanodePlugins;
    }

    @Override
    public void shutDown() {
        
		//send notification 
         Notification notify=new Notification();
         notify.setHostId(hostname);
         notify.setId("HADOOP/DOWN");
         this.sendNotification(notify);
         logger.info("notification HADOOP/DOWN sent");
        
    }
}
