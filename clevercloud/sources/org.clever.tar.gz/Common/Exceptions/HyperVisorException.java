package org.clever.Common.Exceptions;


public class HyperVisorException extends CleverException{

    public HyperVisorException(){
        super();
    }

    public HyperVisorException(String string){
        super(string);
    }
}







