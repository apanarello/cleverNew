package org.clever.Common.Exceptions;


public class SaveStateException extends HyperVisorException{
    public SaveStateException(String string){
        super(string);
    }
}