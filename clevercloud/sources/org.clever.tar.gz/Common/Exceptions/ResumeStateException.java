package org.clever.Common.Exceptions;


public class ResumeStateException extends HyperVisorException{
    public ResumeStateException (String string){
        super(string);
    }
}