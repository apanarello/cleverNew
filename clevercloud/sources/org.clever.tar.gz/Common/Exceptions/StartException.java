package org.clever.Common.Exceptions;

public class StartException extends HyperVisorException{
    public StartException(String string){
        super(string);
    }
}
