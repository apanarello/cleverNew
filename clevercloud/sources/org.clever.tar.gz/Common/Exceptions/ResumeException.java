package org.clever.Common.Exceptions;

public class ResumeException extends HyperVisorException{
    public ResumeException(String string){
        super(string);
    }
}